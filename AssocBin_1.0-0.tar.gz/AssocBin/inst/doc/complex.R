## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(AssocBin)

## -----------------------------------------------------------------------------
data(heart)
summary(heart)

## -----------------------------------------------------------------------------
heartClean <- heart
heartClean$thal <- NULL
heartClean$ca <- NULL
heartClean$slope <- NULL
heartClean <- na.omit(heartClean)
str(heartClean)

## -----------------------------------------------------------------------------
stopCrits <- makeCriteria(depth >= 6, n < 1, expn <= 10)
assocs <- pairwiseAssociation(heartClean, stopCriteria = stopCrits, 
                              returnBinnings = TRUE)

## -----------------------------------------------------------------------------
pvals <- pchisq(sapply(assocs$statistic, function(x) x$stat), 
                df = assocs$df, lower.tail = FALSE)

## -----------------------------------------------------------------------------
pord <- order(pvals, decreasing = FALSE)

